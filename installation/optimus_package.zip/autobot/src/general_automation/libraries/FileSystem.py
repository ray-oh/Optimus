#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).

    elif codeID.lower() == 'copyFile'.lower():   _copyFile(codeValue)       # copyFile:source,dest  e.g. copy file to one drive sync folder
    elif codeID.lower() == 'moveFile'.lower():    _moveFile(codeValue)    # moveFile:source,dest  e.g. copy file to one drive sync folder
    elif codeID.lower() == 'makeDir'.lower():     _makeDir(codeValue)     # makeDir:pathname
    elif codeID.lower() == 'removeFile'.lower():  _removeFile(codeValue)        # removeFile:source,dest  e.g. copy file to one drive sync folder
    elif codeID.lower() == 'renameRecentDownloadFile'.lower(): _renameRecentDownloadFile(codeValue) # renameRecentDownloadFile:saveName,path,fileExtension,withinLastSec
    elif codeID.lower() == 'touchFile'.lower(): _touchFile(codeValue) # touch file https://stackoverflow.com/questions/1158076/implement-touch-using-python

"""
from core.lexicon import validate_args, type_check

@validate_args
@type_check
def waitFile(file_pattern:str, action:str, timeout:int, actionIfTimeout:str):
    """Wait for file to appear within timeout period.

    Example: 
        mergeFiles:
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    # https://www.geeksforgeeks.org/create-a-watchdog-in-python-to-look-for-filesystem-changes/
    #tmpDict = parseArguments('file_pattern, action, timeout, actionIfTimeout',codeValue)  # waitFile: file_pattern, action, timeout, actionIfTimeout
    timeout = int(timeout)   # timeout in sec
    logger.debug(f'{log_space}checking 1...')

    return [], [], []

@validate_args
@type_check
def copyFile(source:str , dest:str):
    """Copy file from source to destination.

    Example: 
        copyFile: {{source}} , {{destination}}
    """
    #source = codeValue.split(',',1)[0]
    #dest = codeValue.split(',',1)[1]
    #logg('copyFile:', source = source, dest = dest)
    import os
    import shutil
    destination = shutil.copyfile(source, dest)
    #logg("Path of copied file:", destination = destination)

@validate_args
@type_check
def moveFile(source:str , dest:str):
    """Move file from source to destination.

    Example: 
        moveFile: {{source}} , {{destination}}
    """
    #source = codeValue.split(',',1)[0]
    #dest = codeValue.split(',',1)[1]
    #logg('moveFile:', source = source, dest = dest)
    import os
    import shutil
    destination = shutil.move(source, dest)
    #logg("Path of moved file:", destination = destination)

@validate_args
@type_check
def makeDir(path:str):
    """Create a new directory with given path.

    Example: 
        makeDir: {{path}}
    """
    #path = codeValue.split(',',1)[0]
    import pathlib
    p = pathlib.Path(path)
    p.mkdir(parents=True, exist_ok=True)
    print("      ","Directory created", path)

@validate_args
@type_check
def removeFile(filePattern:str):
    """Remove file with given file pattern.

    Example: 
        removeFile: {{file pattern}}
    """
    #filePattern = codeValue
    #logg('removeFile:', filePattern = filePattern)
    import os, glob
    # Getting All Files List
    fileList = glob.glob(filePattern, recursive=True)
    # Remove all files one by one
    for file in fileList:
        try:
            os.remove(file)
        except OSError:
            print("      ","Error while deleting file")
    #logg("Removed all matched files!")
    print("      ","Removed all matched files!")


@validate_args
@type_check
def renameRecentDownload(saveName:str = None, saveName_suffix:str = '' ,sourcePath:str = './', targetPath:str = './', \
                         fileExtension:str = 'pdf', withinLastSec:int = 12000):
    """Rename recently downloaded file

    Example: 
        renameRecentDownload: download_save ,   , D:/Output/Daily_Sales/ , D:\\target_folder\\ , pdf , 1200
    """
    from auto_utility_file import GetRecentCreatedFile, runInBackground, renameFile    
    # e.g. codeValue = 'renameRecentDownloadFile:D:/iCristal/Output/APAC_Daily_Sales/,D:\\iCristal\\,*.pdf,120'
    #tmpDict = parseArguments('saveName,saveName_suffix,sourcePath,targetPath,fileExtension,withinLastSec',codeValue)
    #print('renameRecentDownloadFile','saveName,saveName_suffix,sourcePath,targetPath,fileExtension,withinLastSec', tmpDict)
    """
    if 'saveName' in tmpDict:
        #logg('saveName', saveName = tmpDict['saveName'].strip())
        saveName = tmpDict['saveName'].strip()
        if saveName == '': saveName = variables['url']
    if 'saveName_suffix' in tmpDict:
        #logg('saveName_suffix',saveName_suffix = tmpDict['saveName_suffix'].strip())
        saveName_suffix = tmpDict['saveName_suffix'].strip()
        if saveName_suffix == '': saveName_suffix = ''
    if 'sourcePath' in tmpDict:
        #logg('sourcePath',sourcePath = tmpDict['sourcePath'])  # D:\\iCristal\\
        sourcePath = tmpDict['sourcePath'].strip()
        if sourcePath == '': sourcePath = './' #'.\\' #'D:\\iCristal\\'
    if 'targetPath' in tmpDict:
        #logg('targetPath', targetPath = tmpDict['targetPath'])  # 'D:/iCristal/Output/APAC_Daily_Sales/'
        targetPath = tmpDict['targetPath'].strip()
        if targetPath == '': targetPath = './' #'./Output/APAC_Daily_Sales/' #'D:/iCristal/Output/APAC_Daily_Sales/'
    if 'fileExtension' in tmpDict:
        #logg('fileExtension', fileExtension = tmpDict['fileExtension'])
        fileExtension = tmpDict['fileExtension'].strip()
        if fileExtension == '': fileExtension = 'pdf'
    if 'withinLastSec' in tmpDict:
        #logg('withinLastSec', withinLastSec = tmpDict['withinLastSec'])
        withinLastSec = tmpDict['withinLastSec'].strip()
        if withinLastSec == '':
            withinLastSec = 12000
        else:
            withinLastSec = int(withinLastSec)
    """
    if saveName == None:
        from config import variables
        saveName = variables['url']
    saveName = saveName + saveName_suffix
    downloadedFile = GetRecentCreatedFile(sourcePath,'*.' + fileExtension, withinLastSec) # get most recent file of pdf format in last 120 sec in path
    #logg('renameFile parameters', targetPath = targetPath, saveName = saveName, fileExtension = fileExtension, level = 'debug')
    #logg('Recent Download file : none', level = 'error') if downloadedFile is None else #logg('Recent Download file:', downloadFile = downloadedFile, targetPath = targetPath, saveName = saveName, fileExtension = fileExtension, level = 'info')
    if downloadedFile is not None: renameFile(downloadedFile, targetPath + saveName + '.' + fileExtension)

@validate_args
@type_check
def touchFile(file:str, path:str = ""):
    """Touch file will update the file modification time.  Or create the file if it does not exist.

    Example: 
        touchFile: {{file}} , {{path}}
    """
    # touchFile: file, path optional
    # e.g. codeValue = 'renameRecentDownloadFile:D:/iCristal/Output/APAC_Daily_Sales/,D:\\iCristal\\,*.pdf,120'
    #tmpDict = parseArguments('file, path',codeValue)
    #print('touchFile','file,path', tmpDict)

    from pathlib import Path
    #_path = "D:\OneDrive-Sync\OneDrive\RPA Project-APAC_FIN\Daily Report" # "." # path/to/
    #Path(_path, 'status.txt').touch()
    """
    if path != None:
        _path = path
    else:
        _path = ""
    """
    Path(path, file).touch()

    #filename = codeValue.split(',',1)[0].strip()
    #msg = codeValue.split(',',1)[1].strip()
    #flow_run_name = context.get_run_context().flow_run.dict()['name']  # error if this is not executed in a flow
    #from auto_core_lib import touchFile 
    #r.telegram(int(id),f"{flow_run_name}-{msg}")
    #print(touchFile(filename))

    #if 'saveName' in tmpDict:

    #source = codeValue.split(',',1)[0]
    #dest = codeValue.split(',',1)[1]
    #logg('moveFile:', source = source, dest = dest)
    #import os
    #import shutil
    #destination = shutil.move(source, dest)
    #logg("Path of moved file:", destination = destination)

