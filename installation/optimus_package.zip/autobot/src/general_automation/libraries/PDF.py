#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).

    elif codeID.lower() == 'createPDF'.lower():   _createPDF(codeValue, df)

    #add_page_numbers(saveFile, pageTitles)
    #addContentPDF(pdf_path, pageTitles, file_extension = '_' + yesterdayYYYYMMDD + '.pdf')
    #addContentPDF:pageTitles,sourcePDF,targetPDF
    elif codeID.lower() == 'addContentPDF'.lower():  _addContentPDF(codeValue, df)

"""
from core.lexicon import validate_args, type_check

from auto_utility_PDF_Image import cropImage, createPDFfromImages, addContentPDF

@validate_args
@type_check
def createPDF(imagelist:str , outputPath:str = None , saveFileName:str = None, df=str):
    """Create PDF from a list of image files.

    Example: 
        createPDF: {{image file list}} , {{output path}} , {{save file name}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure

    #tmpDict = parseArguments('imagelist,outputPath,saveFileName',codeValue)
    if imagelist != None:
        #logg('imagelist', content = tmpDict['imagelist'].strip())
        imagelist = imagelist.strip()
        imagelist = dfObjList(df, imagelist)

        #logg('imagelist', imagelist = imagelist)
        #if imagelist == '': imagelist = ''
        if imagelist == None:
            #imagelist = ''
            logger.error('Error - no imagelist ...')
        else:
            if outputPath != None:
                #logg('outputPath', content = tmpDict['outputPath'])  # D:\\iCristal\\
                outputPath = outputPath.strip()
                if outputPath == '': outputPath = './' #'.\\' #'D:\\iCristal\\'
            if saveFileName != None:
                #logg('saveFileName', content = tmpDict['saveFileName'])  # 'D:/iCristal/Output/APAC_Daily_Sales/'
                saveFileName = saveFileName.strip()
                if saveFileName == '': saveFileName = './savefile.pdf' #'./Output/APAC_Daily_Sales/' #'D:/iCristal/Output/APAC_Daily_Sales/'
            createPDFfromImages(imagelist, outputPath, saveFileName)


@validate_args
@type_check
def addContentPDF(pageTitles:str , sourcePDF:str , targetPDF:str , df):
    """Add content to PDF file e.g. page titles

    Example: 
        addContentPDF: {{page titles}} , {{source PDF file}} , {{target PDF file}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner
    logger = get_run_logger()    
    log_space = "          "

    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER

    #tmpDict = parseArguments('pageTitles,sourcePDF,targetPDF',codeValue)
    if pageTitles != None:
        #logg('pageTitles', content = tmpDict['pageTitles'].strip())
        pageTitles = pageTitles.strip()
        pageTitlesList = dfObjList(df, pageTitles)
        #logg('pageTitlesList', pageTitlesList = pageTitlesList)
        if not len(pageTitlesList) : return # error - no pageTitles provided
    if sourcePDF != None:
        #logg('sourcePDF', content = tmpDict['sourcePDF'])  # D:\\iCristal\\
        sourcePDF = sourcePDF.strip()
        if sourcePDF == '': return # error - no pdf_path defined
    if targetPDF != None:
        #logg('targetPDF', content = tmpDict['targetPDF'])  # 'D:/iCristal/Output/APAC_Daily_Sales/'
        targetPDF = targetPDF.strip()
        file_extension = '_' + yesterdayYYYYMMDD + '.pdf'
        if targetPDF == '': targetPDF = sourcePDF + file_extension #'./Output/APAC_Daily_Sales/' #'D:/iCristal/Output/APAC_Daily_Sales/'
    addContentPDF(pageTitlesList, sourcePDF, targetPDF)



