'''
The canonical way to share information across modules within a single program is to create a special module (often called config or cfg). 
Just import the config module in all modules of your application; the module then becomes available as a global name. 
Because there is only one instance of each module, any changes made to the module object get reflected everywhere.
'''
##################### Global Variables ###################################

#from sys_variables import log_space, 

#Exit codes
EX_CONFIG = 1
EX_SOFTWARE = 2
EX_OK = 0

#logging
log_space = "          "
FLOW_COUNT = 0
TASK_COUNT = 0

from datetime import datetime, timedelta
startTime = datetime.now()

#from run import PREFECT_DEPLOYMENT_RUN #, TEST1VAR, TEST2VAR
#from sys_variables import newVariables

# define a 3am cut off
if int(datetime.now().strftime('%H%M'))>=300:
    yesterday = datetime.today() - timedelta(days=1)
else:
    yesterday = datetime.today() - timedelta(days=2)
yesterdayYYYYMMDD = yesterday.strftime('%Y%m%d')
yesterdayDDMMYYYY = yesterday.strftime('%d/%m/%Y')
yesterdayDD_MMY_YYYY = yesterday.strftime('%d/%m/%Y')
now_hhmmss = datetime.now().strftime('%H%M%S')
# system variables
constants = {}
constants['yesterdayYYYYMMDD'] = yesterday.strftime('%Y%m%d')
constants['yesterdayDDMMYYYY'] = yesterday.strftime('%d%m%Y')
constants['todayYYYYMMDD'] = datetime.today().strftime('%Y%m%d')
constants['todayDDMMYYYY'] = datetime.today().strftime('%d/%m/%Y')
constants['yesterdayDD_MM_YYYY'] = yesterday.strftime('%d/%m/%Y')
constants['now_hhmmss'] = datetime.now().strftime('%H%M%S')

#tmpObj = {}
#variables = {}
#tmpObj['iterationCount'] = 0
constants['iterationCount'] = 0
#constant['iterationCount'] = tmpObj['iterationCount']
#variables['iterationCount'] = variables['iterationCount']

# declare user defined variables
variables = {}
#system variables that are pre-declared
variables['i']=None
variables['present']=None
variables['exist']=None
variables['count']=None
variables['loopCount']=None
variables['sentEmailCheck_hour']=3  # used by email program to check if email has already been sent (duplicate subject since this cut off time for the day)
variables['sentEmailCheck_min']=15  # default value can be overwritten in excel script: e.g. set:sentEmailCheck_min=0
variables['headless_mode']=False # '{"visual_automation":True, "chrome_browser":True, "headless_mode":False, "turbo_mode":False}' # default browser mode

variables['rpaBrowser']=False
variables['optimusDF']=None
variables['optimusobjVar']=None
variables['record_video_dir']="None"

#variables['codeVersion']=str(flow_run_name)  #'test-codeVersion'
#variables['flowrun']='test-flow'
#variables['arguments']=program_args['arguments']
#variables['flow_run_name']=flow_run_name
#variables['flowrun']=flow_run_name

codeVersion = 'version 23.8.22'
variables['codeVersion']=codeVersion

#script_version = '2022.10.27'
flow_run_name = ''
PROGRAM_DIR = ''
AUTOBOT_DIR = ''
SCRIPTS_DIR = ''
ASSETS_DIR = ''
OUTPUT_PATH = '/output'
IMAGE_PATH = '/rpa'
LOG_PATH = '/log'
ADDON_PATH = '/addon'
SRCLOGFILE = 'generalAutomation.log'

BACKGROUND = ''
UPDATE = ''
RETRIES = ''
STARTFILE = ''
STARTCODE = ''
STARTSHEET = ''
RPABROWSER = 0 # 0 = TagUI (default) 1=playwright
VERSION = ''

#from job_monitor import memoryPath
# MEMORYPATH = "D:\OneDrive-Sync\OneDrive\Shared Documents - RPA Project-APAC_FIN\Status"
MEMORYPATH = ''    #r"\Optimus\memory"
#D:\OneDrive-Sync\OneDrive\Shared Documents - RPA Project-APAC_FIN\Status"

##################### Global Functions ###################################
from job_monitor import touchFile, stateChange, write_yaml, read_yaml, triggerRPA

configObj = None
program_args = None
configuResultMsg = None
isDeploymentFlowRun = False
CWD_DIR = ''
IMAGE_DIR = ''