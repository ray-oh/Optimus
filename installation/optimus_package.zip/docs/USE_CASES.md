# Use Cases



# Enhancements / Requests

New browser driver option
- Playwright for Python
  - https://playwright.dev/python/docs/intro
  - https://github.com/microsoft/playwright-python
  - https://eldadu1985.medium.com/robotframework-browser-automation-tools-a-review-for-2021-29a0835f437d
    - Robotframework Selenium Library
       - https://robotframework.org/SeleniumLibrary/SeleniumLibrary.html#library-documentation-top
    - Robotframework Puppeteer Library
    - Robotframework Browser Library
      - https://robotframework-browser.org/#training
      - https://marketsquare.github.io/robotframework-browser/Browser.html
    - Robotframework Playwbot
   
Robotframework
- https://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#test-setup-and-teardown
 
Robocorp
- https://robocorp.com/docs/libraries/rpa-framework/rpa-desktop

