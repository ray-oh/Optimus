Import-Module D:\Optimus-Prefect-Test1\OneDriveLib.dll
Get-ODStatus

Start-Sleep -s 100000
