# declare user defined variables
newVariables = {}
#system variables that are pre-declared
newVariables['i']=None