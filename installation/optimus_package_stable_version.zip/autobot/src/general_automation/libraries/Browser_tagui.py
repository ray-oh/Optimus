#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
An always available standard library with often needed keywords.

BuiltIn is Optimus's standard library that provides a set of generic keywords needed often. It is imported automatically and thus always available.
The provided keywords can be used, for example, for verifications (e.g. Should Be Equal, Should Contain), conversions (e.g. Convert To Integer) and 
for various other purposes (e.g. Log, Sleep, Run Keyword If, Set Global Variable).
"""
from core.lexicon import validate_args, type_check

from config import RPABROWSER, IMAGE_DIR, variables
from auto_helper_lib import CriticalAccessFailure
from auto_utility_browser import waitIdentifierExist
from pathlib import Path, PureWindowsPath
import rpa as r

from browser import p
#Browser
#p = Browser()

@validate_args
@type_check
def click(element_identifier:str):
    """Click given element identifier

    Example:
        click: {{element identifier}}
    """
    code = element_identifier
    try:
        int(len(code))
    except ValueError:
        # not int
        #logg('Not int - code is nan', level = 'error')
        return None
    #print('click', code)
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p

        p.click(code)       
    else:    
        if not waitIdentifierExist(code, 30, 1):        # identifier, time_sec, interval
                #logg('      Time out - unable to process step', level = 'critical')           #constants['lastCodelist'] = codeList  
                raise CriticalAccessFailure("Exception critical failure")              
                return
        if code.lower().endswith(('.png', '.jpg', '.jpeg')): code = Path(IMAGE_DIR + '/' + code).absolute().__str__() 
        r.click(code)
    #print('      ','click',code)
    #logg('click', code = code, level = 'debug')
    return None 

@validate_args
@type_check
def rclick(element_identifier:str):
    """Right click of given element identifier

    Example:
        rclick: {{element_identifier}}
    """
    codeValue=element_identifier
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p

        p.click(codeValue, button="right")        
    else:
        if codeValue.lower().endswith(('.png', '.jpg', '.jpeg')): codeValue = Path(IMAGE_DIR + '/' + codeValue).absolute().__str__() 
        r.rclick(codeValue)             # print('rclick',prefix[1])
        #print('      ','rclick',codeValue)
    return None

@validate_args
@type_check
def hover(element_identifier:str):
    """Move mouse to / hover over matching element (or x, y using visual automation for tagui)	

    Example:
        hover: {{element identifier}}
    """
    code = element_identifier
    try:
        int(len(code))
    except ValueError:
        # not int
        #logg('Not int - code is nan', level = 'error')
        return None
    #print('hover', code)
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p

        p.hover(code)       
    else:    
        if not waitIdentifierExist(code, 30, 1):        # identifier, time_sec, interval
                #logg('      Time out - unable to process step', level = 'critical')           #constants['lastCodelist'] = codeList  
                raise CriticalAccessFailure("Exception critical failure")              
                return
        if code.lower().endswith(('.png', '.jpg', '.jpeg')): code = Path(IMAGE_DIR + '/' + code).absolute().__str__() 
        r.hover(code)
    #print('      ','hover',code)
    #logg('click', code = code, level = 'debug')
    return None 


@validate_args
@type_check
def present(element_identifier:str):
    """Check if element identifier is present. Returns True/False in variable 'present'.

    Example:
        present: {{element identifier}}
    """
    codeValue = element_identifier
    codeID = present.__name__
    import config
    config.variables[codeID] = r.present(codeValue)             # print('rclick',prefix[1])
    #print('      ',codeID,config.variables[codeID])
    return None

@validate_args
@type_check
def exist(codeValue:str , variable:str=None, **kwargs):
    """Returns True or False for whether a given element identifier exist/is visible or not.

    Example: 
        exist: identifier , save result to variable name (if not specified, saves it to the variable name "exist")
    """
    from prefect import task, flow, get_run_logger, context
    logger = get_run_logger()

    from config import constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config

    #print('      ','=========Exist1: codeValue:',codeValue, 'variable',variable)
    if variable==None:codeID = exist.__name__
    else:codeID = variable
    if RPABROWSER == 1 or RPABROWSER == 2:
        import browser
        #from browser import p

        config.variables[codeID] = browser.p.selector_exists(codeValue)        
    else:
        config.variables[codeID] = r.exist(codeValue)             # print('rclick',prefix[1])
    logger.debug(f'{log_space}Exist: {codeID}, {config.variables[codeID]}')
    return None

@validate_args
@type_check
def closeRPA(*args, **kwargs):
    """Closes the RPA browser session and window.

    Example:
        closeRPA:
    """
    from prefect import task, flow, get_run_logger, context

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config
    logger = get_run_logger()

    if config.variables['rpaBrowser']:

        #if not browserDisable:
        if RPABROWSER==0:
            instantiatedRPA = r.close()    
        else:
            from browser import p

            p.close_browser()
            instantiatedRPA = True
        logger.debug(f"{log_space}Close RPA = {instantiatedRPA}")
        #logg('Close RPA ', result = instantiatedRPA, level = 'info')

        config.variables['rpaBrowser'] = False
    return None

# used by tagui to redirect console output to a variable
def consoleOutput(runStatement):
    from io import StringIO
    import sys
    old_stdout = sys.stdout # reference current console std out
    buffer = StringIO()     
    sys.stdout = buffer     # redirect std out to buffer
    exec(runStatement)
    buffer_output = buffer.getvalue()   # assign buffer to variable
    sys.stdout = old_stdout   # reset std out
    #sys.stdout = sys.__stdout__
    return buffer_output

from io import StringIO
import sys
def redirectConsole():
    old_stdout = sys.stdout # reference current console std out
    buffer = StringIO()     
    sys.stdout = buffer     # redirect std out to buffer
    return buffer, old_stdout

def resetConsole(buffer, old_stdout):
    buffer_output = buffer.getvalue()   # assign buffer to variable
    sys.stdout = old_stdout   # reset std out
    #sys.stdout = sys.__stdout__
    return buffer_output

@validate_args
@type_check
def url(key:str , *args, authentication:int=0, user:str='', origin:str=''):
    """Go to specific url page.
    For playwright driver, additional arguments for authentication are accepted to pass authentication credentials.
    Authentication credentials are retrieved from default chrome browser profile.
    authentication: 1 for authentication. Default is 0, i.e. no authentication.
    user: e.g. email address.
    origin: url in chrome profile where the credential is stored.

    Example: 
        url: {{url address}} , {{authentication}} , {{user}} , {{origin}}
    """
    from prefect import task, flow, get_run_logger, context

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure

    from browser import p
    logger = get_run_logger()

    import config
    df = config.variables['optimusDF']    

    logger.warning(f'URL: RPABROWSER {RPABROWSER} {key} {authentication} {user} {origin}')
    if isinstance(key, str) and key[:4]=='http':  # value given is a URL value
        #logger.info(f"      Valid URL")
        url_value = key
    elif key[:1]=='@':                            # value given is a URL value with special prefix @
        url_value = key[1:]
    else:                                         # name of list (key value pair) expected
        #print('check df',df)
        url_value = dfKey_value(df, key)
        #print('      ','URL:',key, url_value) #, type(url_value))
        #logger.info(f"      DEBUG url: ', VARIABLE_TYPE = {type(url_value)}, key = {key}, url_value = {url_value}")
        logger.debug(f"{log_space}Open URL: {url_value}")

    import math
    #x = float('nan')
    #math.isnan(x)

    if url_value==None or url_value!=url_value:  #df key value returns empty value
        logger.info(f"      Not a valid key value pair. url_value = {url_value} key = {key}, level = 'warning'")            
    elif not(isinstance(url_value, str)):
        url_value = url_value[0]
        #logg('IsInstanceOfStr', key = key, url_value = url_value)
    if isinstance(url_value, str) and (url_value[:4]=='http' or url_value[:6]=='chrome'):
        #runStatement = \
        #                '''
        #                result = r.url(url_value) # true if run is successful
        #                '''
        #print(consoleOutput(runStatement))
        if RPABROWSER == 0:
            buffer, old_stdout = redirectConsole()
            result = r.url(url_value) # true if run is successful
            consoleOutput = resetConsole(buffer, old_stdout)
            if not result:
                logger.info(f"      RPA ERROR: {consoleOutput}")
            else:
                from auto_helper_lib import Window
                selectedWindows = Window()  # instantiate windows object with snapshot of existing windows
                #selectedWindows.getNew()    # get newly opened windows compared to previous snapshot
                title=r.title()
                if title=='': title='about:blank'
                print('title of window to focus', title)
                selectedWindows.focus(name=title) #'google chrome') # focus the newly opend window with name of
        else:  # RPABROWSER == 1 or RPABROWSER == 2:
            logger.warning(f'{RPABROWSER} {key} {authentication} {user} {origin}')
            if authentication == 1:
                if user != '':
                    if origin != '':
                        p.page_goto(url_value, 1, user, origin)
                    else:
                        p.page_goto(url_value, 1, user)
                else:
                    p.page_goto(url_value, 1)
            else:
                p.page_goto(url_value)
            result = True

    else:
        logger.info(f"      ERROR: Not http address, url_value = {url_value}, key = {key}, level = 'warning'")
    constants['url'] = key          # set the URL key/name to a temp varaible with label url
    return None

def urls(codeValue:str, **kwargs):
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
      

    #logg('urls',codeValue = codeValue, objVar = objVar)
    url = dfKey_value(df, objVar).strip()                
    #logg('url', objVar = objVar, url = url)
    r.url(url)
    constants['url'] = objVar.strip()
    return None

@validate_args
@type_check
def initializeRPA(codeValue: str=None, *args, **kwargs):
    """Initialize RPA browser before any browser action.
    For tagui, you can specific a json string object to over write the default values.

    Example: 
        initializeRPA: {visual_automation = False, chrome_browser = True, headless_mode = False, turbo_mode = False}
    """
    from prefect import task, flow, get_run_logger, context

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
      
    import config
    logger = get_run_logger()
    #print('******* Init:', codeValue, ' | ', args, ' | ',kwargs)
    if not config.variables['rpaBrowser']:

        # Playwright browser
        if RPABROWSER == 1 or RPABROWSER == 2:
            if codeValue=="" or codeValue==None:
                codeValue = "{}"
            #logger.warning(f'{log_space}InitializeRPA codeValue{codeValue}================')
            try:
                import json
                json_object = json.loads(codeValue)
            except Exception as error:
                logger.error('{0}Initialization Error: {1} | {2}'.format(log_space, type(error).__name__, error))
                #logger.debug(log_space+traceback.format_exc())

            var_exists = 'p' in globals() #'p' in locals() or 'p' in globals()
            global p
            if var_exists:
                del p
                p_exists = 'p' in globals() #'p' in locals() or 'p' in globals()            
                #logger.warning(log_space+"Deleted object p exist " + p_exists.__str__())
            import browser
            browser.p = browser.Browser()
            browser.p.initialize(**json_object)
            p_exists = 'p' in globals() #'p' in locals() or 'p' in globals()           
            #logger.warning(log_space+"Initialized object p exist " + p_exists.__str__())

        # TAGUI browser
        else:

            from auto_helper_lib import Window, process_list
            processResult = process_list(name='', minutes=5)
            #selectedWindows = windows_getTitle(name='')
            selectedWindows = Window()  # instantiate windows object with snapshot of existing windows
            #logger.debug(f'{log_space}Windows: {selectedWindows.title}')

            #if not browserDisable:
            #r.init()
            # init(visual_automation = False, chrome_browser = True, headless_mode = False, turbo_mode = False):
            #instantiatedRPA = r.init(visual_automation = True)

            if config.variables['headless_mode']==True:
                visual_automation = False
                chrome_browser = True
                headless_mode = True
                turbo_mode = False
            else: # variables['headless_mode']==False:
                visual_automation = True #False
                chrome_browser = True
                headless_mode = False
                turbo_mode = False

            jsonString = codeValue.strip()
            #jsonString='{"visual_automation":False, "chrome_browser":True, "headless_mode":True, "turbo_mode":False}' # overwrite setting in command

            import json
            #jsonString = '{"file":"C:\\Users\\roh\\Downloads\\d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx", "country": "All"}'
            #jsonString = '{"file": "C:/Users/roh/Downloads/d5c7a4f7-b9a7-4d1e-904e-ce7349e0f27c.xlsx", "country": "All"}'
            if jsonString == '':
                pass
            else:
                try:
                    paramDict = json.loads(jsonString.lower())
                    #logger.info(f"parameter dictionary = {paramDict}")    
                    #print(paramDict['file'])
                    #print(paramDict['country'])
                    #print(jsonString, paramDict)
                    logger.debug(f"{log_space}RPA Initialize Parameters = {jsonString}, {paramDict}")
                    for item in paramDict:
                        if item == "visual_automation": visual_automation=paramDict[item]
                        elif item == "chrome_browser": chrome_browser=paramDict[item]
                        elif item == "headless_mode": headless_mode=paramDict[item]
                        elif item == "turbo_mode": turbo_mode=paramDict[item]
                        #print(item)
                        #print(f"{item}={paramDict[item]}")
                        #exec(f"{item}={paramDict[item]}")  # modify variables
                    print(visual_automation, chrome_browser, headless_mode, turbo_mode, type(visual_automation))
                except:
                    print("Error json string in _initializeRPA:", jsonString)

            instantiatedRPA = r.init(visual_automation = visual_automation, chrome_browser = chrome_browser, headless_mode = headless_mode, turbo_mode = turbo_mode)
            print(f"r.init(visual_automation = {visual_automation}, chrome_browser = {chrome_browser}, headless_mode = {headless_mode}, turbo_mode = {turbo_mode})")
            #logg('Initialize RPA', result = instantiatedRPA, level = 'info')
            logger.debug(f"{log_space}Initialize RPA = {instantiatedRPA}")

            if instantiatedRPA:
                selectedWindows.getNew()    # get newly opened windows compared to previous snapshot
                title=r.title()
                if title=='': title='about:blank'
                selectedWindows.focus(name=title) #'google chrome') # focus the newly opend window with name of

        import config
        config.variables['rpaBrowser'] = True
    return None


import time

#@task
@validate_args
@type_check
def wait(timeout:str = None, identifier:str = None, run_code:str = None, run_code_until:str = None): #, df = None, objVar = None, **kwargs):
    """Wait for identifier to appear.
    Arguments: timeout_sec , identifier , run_code if timeout , run_code_until

    Example: 
        wait: 30 , identifier , code to run if timeout or if not specified pass to next action
    """
    from prefect import task, flow, get_run_logger, context

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
      
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
    from config import variables
    df = variables['optimusDF']
    objVar = variables['optimusobjVar']

    logger = get_run_logger()

    codeValue = timeout
    import config
    #print('*********************************************************', RPABROWSER)    
    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p

        if codeValue=="" or codeValue==None:    # no parameters
            time_sec=1000        
            time.sleep(time_sec)
            # r.wait(time_sec)
            return []
        if codeValue[:1]=='{':    # parameters in JSON format
            if codeValue=="" or codeValue==None:
                codeValue = "{}"
            #print('-------------wait_codevalue',codeValue)
            import json
            json_object = json.loads(codeValue)
            if 'time_sec' in json_object:
                time_sec = json_object["time_sec"]
                tmpDict = json_object.pop('time_sec')
            else:
                time_sec = 15000
        else:     # parameters not in JSON format
            #tmpDict = parseArguments('time_sec,identifier,run_code,run_code_until',codeValue)  #items = 'wait:15:ID:codeA'
            time_sec = int(codeValue) #int(tmpDict['time_sec'])*1000
            if identifier != None: #'identifier' in tmpDict:                 # do while identifier is found - r.exist
                #logg('identifier', identifier = tmpDict['identifier'])
                #print(log_space, 'wait identifier', identifier)  #tmpDict['identifier']
                # identifier is a special object list
                if identifier in df[(df.Type == 'list')]['Object'].dropna().values.tolist():
                    identifier = dfObjList(df, identifier)
                    #print('wait identifier list', tmpDict['identifier'])
                #logger.debug(f"{log_space}timeout',{time_sec},'selector',{tmpDict['identifier']}")
                #print(log_space, 'time sec:', time_sec, 'identifier:', identifier)
                timeoutError = not p.wait(time_sec * 1000, selector=identifier)
            else:
                time.sleep(int(time_sec))      # time sec is in milli sec
                timeoutError = False    #not p.wait(time_sec)

        #p.initialize(**json_object)
        if timeoutError: #**tmpDict): #int(codeValue)):
            if run_code != None:                                           #run code if time out
                run_code = dfObjList(df, run_code)
                print('wait run code list', run_code)
                logger.debug(f"{log_space}Scenario list:{identifier} Action list:{run_code}")

                #logger.debug(f"      Run code from wait: {tmpDict['run_code']}")

                run_code = run_code #dfObjList(df, tmpDict['run_code'])
                #logg('      Run code:', run_code = run_code)

                #runCodelist(CodeObject(df), run_code)
                n = len(run_code)
                #logger.debug(f"{log_space}Action:{tmpDict['run_code']}, {n} steps:{run_code} {[objVar] * n}")

                return run_code
            else:
                logger.warning(f"{log_space}Time out from waiting ...")
                return []
        return []
    else:
        # tagui Browser
        #tmpDict = parseArguments('time_sec,identifier,run_code,run_code_until',codeValue)  #items = 'wait:15:ID:codeA'
        time_sec = int(codeValue)
        if identifier != None:                 # do while identifier is found - r.exist
            #logg('identifier', identifier = tmpDict['identifier'])
            print('wait identifier', identifier)
            # identifier is a special object list
            if identifier in df[(df.Type == 'list')]['Object'].dropna().values.tolist():
                identifier = dfObjList(df, identifier)
                if run_code != None:                                           #run code if time out
                    run_code = dfObjList(df, run_code)
                print('wait identifier list', identifier)
                print('wait run code list', run_code)

                logger = get_run_logger()
                logger.debug(f"{log_space}Scenario list:{identifier} Action list:{run_code}")

                matchBool, index = waitIdentifierExist(identifier, time_sec, 1, False)         #waitIdentifierExist(identifier, time_seconds, interval) - returns true or false
                if not matchBool:
                    #logg('      Time out from waiting', level = 'warning')                    #raise CriticalAccessFailure("TXT logon window did not appear")
                    logger.warning(f"Time out from waiting ...")
                    return [], [], []
                else:
                    if run_code != None:                                           #run code if time out
                        print('      Run code from wait:', run_code[index])

                        run_code = dfObjList(df, run_code[index])
                        #logg('      Run code:', run_code = run_code)

                        #runCodelist(CodeObject(df), run_code)
                        n = len(run_code)
                        logger.debug(f"{log_space}Action:{run_code[index]}, {n} steps:{run_code} {[objVar] * n}")

                        return run_code
                        #return run_code, [df], [objVar]
                    else:
                        return []

            else: # not a special object list
                if not waitIdentifierExist(identifier, time_sec, 5, False):         #waitIdentifierExist(identifier, time_seconds, interval) - returns true or false
                    #logg('      Time out from waiting', level = 'warning')                    #raise CriticalAccessFailure("TXT logon window did not appear")
                    if run_code != None:                                           #run code if time out
                        run_code = dfObjList(df, run_code)
                        if run_code_until != None:
                            #logg('Time out - run code:', run_code = run_code, run_code_until = tmpDict['run_code_until'], level = 'debug')
                            #runCodelist(CodeObject(df), run_code, '', tmpDict['run_code_until'])
                            n = len(run_code)
                            return run_code                        
                        else:                                                           
                            #logg('      Time out - run code:', run_code = run_code, level = 'error')
                            #runCodelist(CodeObject(df), run_code)
                            n = len(run_code)
                            return run_code
                else:
                    return []

        # no identifier - normal wait
        else:
            #logg('wait', time_sec = time_sec)
            time.sleep(time_sec)
            # r.wait(time_sec)
            return []

@validate_args
@type_check
def keyboard(codeValue: str, *args, **kwargs):
    """Simulates keyboard action.
    key commands: [shift] [ctrl] [alt] [win] [cmd] [enter] 
    [space] [tab] [esc] [backspace] [delete] [clear] 
    [up] [down] [left] [right] [pageup] [pagedown]
    [home] [end] [insert] [f1] .. [f15]
    [printscreen] [scrolllock] [pause] [capslock] [numlock]

    Example: 
        keyboard: {{key commands}}
    """
    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    import config

    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p        
        def mapKeyCodes(test_str):
            # Replace Different characters in String at Once using regex + lambda
            import re
            
            # initializing string
            #test_str = '[ctrl][alt][shift][esc][esc][esc][enter][shift][enter]'
            
            # printing original String
            #print("The original string is : " + str(test_str))
            
            # initializing mapping dictionary
            # key press e.g. [home] [end] [insert] [f1] .. [f15] [shift] [ctrl] [alt] [win] [cmd] [enter] [space] [tab] [esc] [backspace] [delete] [clear]
            # F1 - F12, Digit0- Digit9, KeyA- KeyZ, Backquote, Minus, Equal, Backslash, Backspace, Tab, Delete, Escape, ArrowDown, End, Enter, Home, Insert, PageDown, PageUp, ArrowRight, ArrowUp, etc.
            # Following modification shortcuts are also supported: Shift, Control, Alt, Meta, ShiftLeft.
            '''
            [shift] [ctrl] [alt] [win] [cmd] [enter]
            [space] [tab] [esc] [backspace] [delete] [clear]
            [up] [down] [left] [right] [pageup] [pagedown]
            [home] [end] [insert] [f1] .. [f15]
            [printscreen] [scrolllock] [pause] [capslock] [numlock]
            https://developer.mozilla.org/en-US/docs/Web/API/UI_Events/Keyboard_event_key_values
            https://tagui.readthedocs.io/en/latest/reference.html
            https://playwright.dev/docs/api/class-keyboard
            https://github.com/tebelorg/RPA-Python#core-functions
            https://www.geeksforgeeks.org/python-replace-different-characters-in-string-at-once/
            '''
            map_dict1 = {'\[':'[','\]':']',
                        '\-':'Minus','\+':'Plus','\=':'Equal',
                    }

            map_dict = {'\[':'[','\]':']',
                        'shift':'Shift+','ctrl':'Control+','alt':'Alt+','win':'Meta','cmd':'Meta','enter':'Enter',
                        'space':'Space','tab':'Tab','esc':'Escape','backspace':'Backspace','delete':'Delete','clear':'Clear',
                        'up':'ArrowUp','down':'ArrowDown','left':'ArrowLeft','right':'ArrowRight','pageup':'PageUp','pagedown':'PageDown',
                        'home':'Home','end':'End','insert':'Insert',
                    }

            map_dict2 = {'\+\]\[':'+','\]':']',
                    }

            # using lambda and regex functions to achieve task
            res = re.compile("|".join(map_dict1.keys())).sub(lambda ele: map_dict1[re.escape(ele.group(0))], test_str)
            res = re.compile("|".join(map_dict.keys())).sub(lambda ele: map_dict[re.escape(ele.group(0))], res) 
            res = re.compile("|".join(map_dict2.keys())).sub(lambda ele: map_dict2[re.escape(ele.group(0))], res)
            if res[-2:]=='+]': res=res[:-2]
            #print('Truncate',res[-2:])
            # printing result
            #print("The converted string : " + str(res))
            #res.split('][')
            import re
            pattern = r'[\[\],;|]'
            result = re.split(pattern, res)
            while("" in result): result.remove("")
            #print(result)
            #for i in result:
            #    print(i)
            return result

        for key in mapKeyCodes(codeValue):
            try:
                #print('Press key:' + key)
                p.press(key)
            except:
                print('Error type' + key)
                p.type(key)
    else:
        r.keyboard(codeValue)           # print('keyboard',prefix[1])
    return None

@validate_args
@type_check
def type(identifier: str, value:str, *args, **kwargs):              # type text at element
    """Enter text at element.

    Example: 
        type: identifier , text to type
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
      
    import config

    #identifier = codeValue.split(',',1)[0].strip()
    #value = codeValue.split(',',1)[1].strip()
    if RPABROWSER == 1 or RPABROWSER == 2: 
        from browser import p        
        p.input(identifier,value)
    else:   
        r.type(identifier,value)
    return None


@validate_args
@type_check
def pause():
    """Pause the script run in browser for user action.
    Special dialog pop up allows user to resume script after manual action.
    Applicable only for playwright.

    Example:
        pause:
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
      
    import config

    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p        
        p.pause()

@validate_args
@type_check
def authenticate(username:str, origin:str, *args, **kwargs):
    """Authenticate a login page.  Applicable only for playwright.
    The credentials are saved in your default chrome browser.
    And retrieved by specifying the "origin" url where its saved in chrome.
    User name and password are updated into input element with username and password id.

    Example: 
        authenticate: {{user name}} , {{origin}}
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
      
    import config


    logger = get_run_logger()

    #tmpDict = parseArguments('username, origin',codeValue)
    #print(tmpDict)
    #if tmpDict == {}: return
    if username=="": return None

    if RPABROWSER == 1 or RPABROWSER == 2:
        from browser import p        
        p.authenticate(username, origin)

@validate_args
@type_check
def read(codeValue:str, value:str=None, **kwargs):
    """Read and return element text at given or specified element identifier.
    For tagui: element_identifier ('page' is web page) (or x1, y1, x2, y2).

    Example: 
        read: variable name to save result , element identifier to read.
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
      
    import config
    print('      READ check:', codeValue, ' | ', value)

    key = codeValue.split('=',1)[0]
    value = codeValue.split('=',1)[1]
    #logg('read:', key = key, value = value)
    if RPABROWSER == 1 or RPABROWSER == 2:
        import browser                
        config.variables[key] = browser.p.read(value)
        print('    READ', config.variables[key])
    else:
        config.variables[key] = r.read(value)  # print('variables(', key, ')=', variables[key])


@validate_args
@type_check
def waitDisappear(timeout:str = None, identifier:str = None, run_code:str=None, run_code_until:str=None):
    """Wait for element identifier to disappear.
    If code to run is not specified, pass to next action upon timeout
    Arguments: 
        timeout_sec , identifier , run_code if timeout , run_code_until

    Example: 
        waitDisappear: 30 , //identifier , code to run if timeout
    """
    from prefect import task, flow, get_run_logger, context

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
      
    import config

    logger = get_run_logger()
    df = variables['optimusDF']
    codeValue = timeout

    #tmpDict = parseArguments('time_sec,identifier,run_code,run_code_until',codeValue)  #items = 'wait:15:ID:codeA'
    if codeValue=="" or codeValue==None:    # no parameters
        time_sec=1000
    else:
        time_sec=int(codeValue)
    if RPABROWSER == 1 or RPABROWSER == 2:
        import browser
        #logger.debug(f'{log_space}checking 1...')
        if identifier != None or identifier != '':                 # do while identifier is found - r.exist
            logger.debug(f"{log_space}identifier = {identifier}")
            start_time = time.time()
            while True:
                #timeoutError 
                Found = browser.p.wait(2000, selector=identifier)
                elapsed_time = int(time.time() - start_time)
                if not Found:
                    logger.info(log_space + 'Disappeared: ' + identifier)
                    return []       #return True                    
                elif elapsed_time > time_sec: #time_seconds:
                    logger.warning(log_space+"Time out from waiting")                    #raise CriticalAccessFailure("TXT logon window did not appear")
                    if run_code != None:                                           #run code if time out
                        run_code = dfObjList(df, run_code)
                        if run_code_until != None:
                            logger.debug(f"{log_space}Time out - run_code = {run_code}, run_code_until = {run_code_until}")
                            #runCodelist(CodeObject(df), run_code, '', tmpDict['run_code_until'])
                            n = len(run_code)
                            return run_code
                        else:                                                           
                            logger.warning(f"{log_space}Time out - run_code = {run_code}")
                            #runCodelist(CodeObject(df), run_code)
                            n = len(run_code)
                            return run_code
                    else:                        
                        return []  #return False  - but no code to run                      
                else:
                    time.sleep(1)
                    #logger.error(log_space + 'Check ' + Found.__str__())
            #return True
            return []

    else:  # RPABrowser = 0 Tagui
        logger.debug(f'{log_space}checking 1...')
        if identifier != None or identifier != '':                 # do while identifier is found - r.exist
            logger.debug(f"{log_space}identifier = {identifier}")
            if not waitIdentifierDisappear(identifier, time_sec, 1, False):         #waitIdentifierExist(identifier, time_seconds, interval) - returns true or false
                logger.warning(f"   Time out from waiting', level = 'warning'")                    #raise CriticalAccessFailure("TXT logon window did not appear")
                if run_code != None:                                           #run code if time out
                    run_code = dfObjList(df, run_code)
                    if run_code_until != None:
                        logger.debug(f"{log_space}Time out - run code: run_code = {run_code}, run_code_until = {run_code_until}, level = 'debug'")
                        #runCodelist(CodeObject(df), run_code, '', tmpDict['run_code_until'])
                        n = len(run_code)
                        return run_code
                    else:                                                           
                        logger.warning(f"'      Time out - run code:', run_code = {run_code}, level = 'warning'")
                        #runCodelist(CodeObject(df), run_code)
                        n = len(run_code)
                        return run_code
            else:
                return []
        else:
            logger.debug(f"{log_space}wait time_sec = {time_sec}")
            time.sleep(time_sec)
            # r.wait(time_sec)
            return []

@validate_args
@type_check
def count(element_identifier:str, **kwargs):
    """Return number of web elements as integer.  Applicable for TagUI.
    Argument: 
        element_identifier

    Example:
        count: {{element identifier}}
    """
    codeID = 'count'
    codeValue = element_identifier
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
      
    import config
    config.variables[codeID] = r.count(codeValue)             # print('rclick',prefix[1])
    print('      ',codeID,config.variables[codeID])

#_focus(codeID, codeValue) # focus() - app_to_focus (full name of app) - make application in focus
@validate_args
@type_check
def focus(app_to_focus:str):
    """Make application in focus.  Specific to tagui browser driver.

    Argument: 
        app_to_focus (full name of app)

    Example: 
        focus: app_to_focus
    """
    codeID = 'focus'
    codeValue = app_to_focus    
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
      
    import config
    config.variables[codeID] = r.focus(codeValue)             # print('rclick',prefix[1])
    print('      ',codeID,config.variables[codeID])

@validate_args
@type_check
def popup(codeValue:str, **kwargs):
    """Set context to web popup tab.  Specific to tagui browser driver.
    """
    codeID = 'popup'
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
      
    import config
    config.variables[codeID] = r.popup(codeValue)             # print('rclick',prefix[1])
    print('      ',codeID,config.variables[codeID])

@validate_args
@type_check
def title():
    """Returns title of current page in the variable "title".

    Example:
        title:
    """
    codeID = 'title'
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
      
    import config
    config.variables[codeID] = r.title()             # print('rclick',prefix[1])
    print('      ',codeID,config.variables[codeID])        

@validate_args
@type_check
def select(key:str, value:str, **kwargs):
    """Selects option or options in <select>.

    Example: 
        select: tag element for <select> , option value
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
      
    import config
    import browser
    #key = codeValue.split(',',1)[0]
    #value = codeValue.split(',',1)[1]
    #print("select", key, value)
    #logg('select:', select = key, option = value)
    if RPABROWSER == 1 or RPABROWSER == 2:
        browser.p.select_option(key, value)
    else:
        r.select(key,value)             # print('select',prefix[1])
    #print("select done")

@validate_args
@type_check
def snap(codeValue:str='page', saveFile:str='', **kwargs):  # snap:page, saveFile
    """Take screenshot of full web page to file.

    Example:  
        snap: page , image.png
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
      
    import config
    import browser
    page = codeValue.split(',',1)[0]        
    if page=='':
        page = 'page'
    elif page =='log':
        snapImage()
        return
    if saveFile=='':saveFile = codeValue.split(',',1)[1].strip()
    from pathlib import Path
    if saveFile=='':
        saveFile = './Output/Images/' + saveFile
    else:
        if Path(saveFile).parent.exists():
            saveFile = Path(saveFile).resolve().__str__()
        else:
            saveFile = Path('./tmp.png').resolve().__str__()
    #logg('######### snap ###########', page = page, saveFile = saveFile, level = 'debug')
    if RPABROWSER == 1 or RPABROWSER == 2: 
        browser.p.snap(path=saveFile, full_page=True)
    else:
        r.snap(page, saveFile)          

@validate_args
@type_check
def telegram(telegram_id:str , text_message:str):
    """Sends notification message via telegram.
    First, look up @rpapybot on your Telegram app to approve receiving messages.
    Message is send in the following format: {flow run name} - message string

    Example: 
        telegram: telegram_id , message_string
    """
    from config import flow_run_name 
    r.telegram(int(telegram_id),f"{flow_run_name} -{text_message}")  #, 'MarkdownV2'

@validate_args
@type_check
def download(download_url:str, filename_to_save:str, **kwargs):
    """Download given url content.

    Example: 
        download: download_url , filename_to_save
    """
    from config import RPABROWSER
    import config
    import browser
    if RPABROWSER == 1 or RPABROWSER == 2:
        browser.p.download(download_url, filename_to_save)
    else:
        r.download(download_url, filename_to_save)

@validate_args
@type_check
def upload(upload_selector:str, file_to_load:str, **kwargs):
    """Upload given specific web locator and file path.

    Example: 
        upload: upload_selector , file_to_load
    """
    from prefect import task, flow, get_run_logger, context
    from prefect.task_runners import SequentialTaskRunner

    from config import variables, constants, STARTFILE, CWD_DIR, IMAGE_DIR, yesterdayYYYYMMDD, log_space, RPABROWSER
    from auto_helper_lib import dfObjList, dfKey_value, readExcelConfig, updateConstants, CriticalAccessFailure
    from auto_utility_browser import waitIdentifierExist, waitIdentifierDisappear, exitProg, snapImage    
      
    import config
    import browser
    #upload_selector = codeValue.split(',',1)[0].strip()
    #file_to_load = codeValue.split(',',1)[1].strip()
    if RPABROWSER == 1 or RPABROWSER == 2:
        browser.p.upload(upload_selector, file_to_load)
    else:
        #r.download(download_url, filename_to_save)
        pass

@validate_args
@type_check
def setView(identifier:str):
    """Sets the target scope for playwright browser action to either existing "frame" or "page" or frame identified by given "identifer".

    Example: 
        setView: page
        setView: frame
        setView: #gsft_main
    """
    from config import RPABROWSER
    import config
    import browser
    # set target frame for playwright
    # if identifier - then use frame locator
    # if value is page then is reset to page
    # if value is frame then set to existing frame
    # else unchange and log false result
    if RPABROWSER == 1 or RPABROWSER == 2:
        if identifier.lower() == 'page':
            browser.p.setView(viewType = 'page')            
        elif identifier.lower() == 'frame':
            browser.p.setView(viewType = 'frame')            
        else:
            browser.p.setView(viewType = 'frame', selector = identifier)
    else:
        pass

@validate_args
@type_check
def recordVideo(True_False:bool=True, record_video_dir:str='.\\output\\'):
    """Activate recording of video for browser automation session.  Only for playwright browser driver.
    Default directory is the script working directory.

    Example: 
        recordVideo: True , D:/test/Video/
        recordVideo: True , ./Video/
        recordVideo: True
        recordVideo: False
    """
    ##print("record video start")
    from config import RPABROWSER
    import config
    if RPABROWSER == 1 or RPABROWSER == 2:
        if True_False:
            config.variables['record_video_dir']=record_video_dir
        else:
            config.variables['record_video_dir']="None"
    else:
        pass
    ##print("record video done")


@validate_args
@type_check
def chromeZoom(factor:int):
    """Zoom in or out in Chrome browser. Playwright: Zoom factor 50=50%, 110=110%
    Tagui: Zoom factor -1 = -90%, -2 = -80%, -3 = -75%, 0 = reset to 100%.

    Example: 
        chromeZoom: 30
    """
    from config import RPABROWSER
    import browser

    if RPABROWSER == 1 or RPABROWSER == 2:
        #jscript = f"() => document.body.style.zoom = {str(factor/100)}"
        jscript= f"document.body.style.zoom={str(factor/100)}"
        browser.p.evaluate( jscript )

    else:
        import rpa as r
        if factor < 0:      zoom_key = '-'  # zoom out
        elif factor > 0:    zoom_key = '+'  # zoom in
        elif factor == 0:   zoom_key = '0'  # Reset to 100%      #ahk.send_input('{Ctrl down}0{Ctrl up}')
        else:               return
        r.keyboard('[ctrl]0')
        for i in range(int(abs(factor))):
            r.keyboard('[ctrl]' + zoom_key) #ahk.send_input('{Ctrl down}' + zoom_plus_minus + '{Ctrl up}')  # zoom -90%, -80%, -75%




