#  Copyright 2020-     Optimus Corp
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

"""
Parse and Validate function arguments given a string

@validate
@type
runs validate first then type_check
"""
import ast

def parse_args(args):
    """Used by validate_args decorator.  To parse an argument string to its function arguments.
    """
    #import re
    def encapsulate_items(my_string:str, delimiter:str=" , "):
        """Encapsulates all items in the string that are separated by the delimiter with quotes
        Example: "command1 , command2" -> "'command1' , 'command2'"
        """
        #pattern = re.compile(r'(?<!\w)\'[^\']*\'[^\']*|(?<!\w)[^\']+' + delimiter + '[^\']+')
        #items = pattern.findall(my_string)
        if my_string.rstrip() == '': return None
        items = my_string.split(delimiter)
        #print('Validate encapsulate_items - split items', items)
        for i in range(len(items)):
            if not items[i].startswith('\'') and not items[i].endswith('\''):
                items[i] = '\'' + items[i].strip().replace("'", "\\'") + '\''

        #print(items)
        #print([item.strip() for item in items])
        return delimiter.join(items)
    #args_list = args.split(' , ')
    #args_list = [f"'{x}'" for x in args_list]
    #args = ' , '.join(args_list)

    ##print('args')
    ##print(args)
    encapsulated_args = encapsulate_items(args)
    
    ##print(encapsulated_args)
    #print([item.lstrip() for item in encapsulated_args])

    if encapsulated_args == None:
        args = 'f()'                                # no arguments
    else:
        args = 'f({})'.format( encapsulated_args )  # create a function with the encapsulated argument string
    ##print('Validate encapsulate_items - args', args)
    tree = ast.parse(args)
    funccall = tree.body[0].value
    #print('funccall tree' , str(funccall.args))
    args = [ast.literal_eval(arg) for arg in funccall.args]
    kwargs = {arg.arg: ast.literal_eval(arg.value) for arg in funccall.keywords}
    return args, kwargs

def validate_args(func):
    """Decorator using ast module to parse argument string into arguments readable by the python function.
    The ast module is a built-in Python library that provides a way to work with the abstract syntax tree (AST) of Python code.
    It is used here to write tools that analyze or transform Python code, or to generate Python code programmatically.
    """
    @functools.wraps(func)    
    def wrapper(args_str, **kwargs):
        ##print('Validate',args_str, kwargs)
        args, kwargs2 = parse_args(args_str)
        ##print('Validate args:', args, 'kwargs2:', kwargs2)
        kwargs = kwargs | kwargs2
        return func(*args, **kwargs)
    return wrapper

import functools

def type_check(func):
    '''Decorator to validate the type of arguments for specified functions in a module.
    Execute check of argument type after validation and parsing of argument string to its function arguments.
    '''
    @functools.wraps(func)
    def check(*args, **kwargs):
        #print('Type check - num ags: ', len(args), ' | args: ', args) #,kwargs)
        #print('func nanme', func.__name__)
        #print('func keys',list(func.__annotations__.keys()))
        #print('func values',list(func.__annotations__.values()))

        # args is a tuple object and immutable.  Convert to list for any conversion, before changing back to tuple
        arg_list = list(args)
        for i in range(len(arg_list)):
            v = arg_list[i]
            v_name = list(func.__annotations__.keys())[i]
            v_type = list(func.__annotations__.values())[i]
            error_msg = 'Variable `' + str(v_name) + '` should be type (' + str(v_type) + ') but instead is type (' + str(type(v)).split("'")[1] + ')'
            #print("Msg", error_msg)
            if isinstance(v , str) and v_type==int:
                #print(f'*** Convert {v} to int') 
                v = int(v)
                arg_list[i] = v
            elif isinstance(v , str) and v_type==bool:
                string_to_bool = {"true": True, "false": False, "1":True, "0":False}
                v = string_to_bool[v.lower()]
                arg_list[i] = v
            #print('*** Types', v, v_type)
            assert isinstance(v, v_type), error_msg
        args = tuple(arg_list)
        #print('**** Type check successful:', args) #, ' | ', kwargs)
        return func(*args, **kwargs)
    return check

@validate_args
@type_check
def my_function(arg1: int, arg2: str = "2", **kwargs):
    print(arg1, arg2, kwargs)

@type_check
def my_function2(arg1: int, arg2: str):
    #model = MyModel(arg1=arg1, arg2=arg2)
    # Do something with the validated input arguments
    pass

def validate_args1(func):
    """Decorator using ast module to parse argument string into arguments readable by the python function.
    The ast module is a built-in Python library that provides a way to work with the abstract syntax tree (AST) of Python code.
    It is used here to write tools that analyze or transform Python code, or to generate Python code programmatically.
    """
    #@functools.wraps(func)    
    def wrapper(args_str, **kwargs):
        print('Validate',args_str, kwargs)
        args, kwargs2 = parse_args(args_str)
        print('Validate args:', args, 'kwargs2:', kwargs2)
        kwargs = kwargs | kwargs2
        return func(*args, **kwargs)
    return wrapper

import functools

def type_check1(func):
    '''Decorator to validate the type of arguments for specified functions in a module.
    Execute check of argument type after validation and parsing of argument string to its function arguments.
    '''
    #@functools.wraps(func)
    def check(*args, **kwargs):
        #print('Type check - num ags: ', len(args), ' | args: ', args) #,kwargs)
        #print('func nanme', func.__name__)
        #print('func keys',list(func.__annotations__.keys()))
        #print('func values',list(func.__annotations__.values()))                
        for i in range(len(args)):
            v = args[i]
            v_name = list(func.__annotations__.keys())[i]
            v_type = list(func.__annotations__.values())[i]
            error_msg = 'Variable `' + str(v_name) + '` should be type (' + str(v_type) + ') but instead is type (' + str(type(v)).split("'")[1] + ')'
            if isinstance(v , str) and v_type==int:
                #print(f'*** Convert {v} to int') 
                v = int(v)
            elif isinstance(v , str) and v_type==bool:
                string_to_bool = {"true": True, "false": False, "1":True, "0":False}
                v = string_to_bool[v.lower()]
            #print('*** Types', v, v_type)
            assert isinstance(v, v_type), error_msg
        #print('**** Type check successful:', args) #, ' | ', kwargs)
        return func(*args, **kwargs)
    return check
