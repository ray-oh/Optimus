# Some notes about setting up of Git for this repo
## For those who are thinking of contributing to this repo

Some issues when performing sync of repo with new git installation - message [Make sure you configure your 'user.email' and 'user.name' in git.](https://stackoverflow.com/questions/54876421/make-sure-you-configure-your-user-email-and-user-name-in-git-when-trying-t)
